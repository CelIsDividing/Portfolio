package resources;

public enum TicketStatus {
	OPEN,
    AWAITING_RESPONSE,
    RESOLVED
}
