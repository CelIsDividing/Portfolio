<?php
// Navbar header - koristi se na svim stranicama
// Zahteva da je session pokrenut u parent fajlu
?>
<div class="navbar">
    <a href="dashboard.php" class="navbar-brand">Horsle</a>
    <div class="nav-items">
        <a href="profile.php" class="nav-link">👤 Moj profil</a>
        <a href="messages.php" class="nav-link">💬 Poruke</a>
        <a href="logout.php" class="nav-link logout-btn">🚪 Odjava</a>
    </div>
</div>
